#ifndef __FLEET_H__
#define __FLEET_H__


// This class stores details about one fleet. There is one of these classes
// for each fleet that is in flight at any given time.
class Fleet
{
	public:
		// Initializes a fleet.
		Fleet(int owner,
			int num_ships,
			int source_planet = -1,
			int destination_planet = -1,
			int total_trip_length = -1,
			int turns_remaining = -1);

		// Returns the playerID of the owner of the fleet. Your player ID is always
		// 1. So if the owner is 1, you own the fleet. If the owner is 2 or some
		// other number, then this fleet belongs to your enemy.
		int GetOwner() const { return m_iOwner; }

		// Returns the number of ships that comprise this fleet.
		int GetShipsCount() const { return m_iShipsCount; }

		// Returns the ID of the planet where this fleet originated.
		int GetSourcePlanet() const { return m_iSourcePlanet; }

		// Returns the ID of the planet where this fleet is headed.
		int GetDestinationPlanet() const { return m_iDestinationPlanet; }

		// Returns the total distance that is being traveled by this fleet. This
		// is the distance between the source planet and the destination planet,
		// rounded up to the nearest whole number.
		int GetTotalTripLength() const { return m_iTotalTripLength; }

		// Returns the number of turns until this fleet reaches its destination. If
		// this value is 1, then the fleet will hit the destination planet next turn.
		uint GetTurnsRemaining() const { return m_iTurnsRemaining; }

	private:
		int m_iOwner;
		int m_iShipsCount;
		int m_iSourcePlanet;
		int m_iDestinationPlanet;
		int m_iTotalTripLength;
		uint m_iTurnsRemaining;
};

#endif
