#include <iostream>

#include "Utils.h"

#include "PlanetWars.h"

#ifdef MYDEBUG
FILE* g_MyLog;
bool  g_bVisualDebug;
#endif

extern void DoTurn(PlanetWars& pw); 

// This is just the main game loop that takes care of communicating with the
// game engine for you. You don't have to understand or change the code below.
int main(int argc, char *argv[])
{
#ifdef MYDEBUG
	if (argc > 1 && strcmp(argv[1], "--visual") == 0)
	{
		g_bVisualDebug = true;
		g_MyLog = stdout;
	}
	else
	{
		g_bVisualDebug = false;
		fopen_s(&g_MyLog, "MyLog.txt", "wt");
	}
	FILE* pInput = NULL;
	fopen_s(&pInput, "Input.txt", "wt");
#endif	

	int iRound = 0;

	string current_line;
	string map_data;
	while (true)
	{
		int c = cin.get();
		current_line += (char)c;
		if (c == '\n') 
		{
#ifdef MYDEBUG
			if (pInput != NULL)
				fputs(current_line.c_str(), pInput);
#endif
			if (current_line.length() >= 2 && current_line.substr(0, 2) == "go")
			{
				PlanetWars pw(map_data, iRound);
				map_data = "";

				DoTurn(pw);
				pw.FinishTurn();

				iRound++;
			}
			else
			{
				map_data += current_line;
			}
			current_line = "";
		}
	}

#ifdef MYDEBUG
	fclose(g_MyLog);
	if (pInput != NULL)
		fclose(pInput);
#endif	

	return 0;
}
