
#include "Utils.h"
#include "Fleet.h"

Fleet::Fleet(int owner, int num_ships, int source_planet, int destination_planet, int total_trip_length, int turns_remaining)
: m_iOwner(owner)
, m_iShipsCount(num_ships)
, m_iSourcePlanet(source_planet)
, m_iDestinationPlanet(destination_planet)
, m_iTotalTripLength(total_trip_length)
, m_iTurnsRemaining(turns_remaining)
{
}

