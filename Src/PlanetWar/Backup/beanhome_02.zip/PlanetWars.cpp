#include "PlanetWars.h"
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

void StringUtil::Tokenize(const string& s, const string& delimiters, vector<string>& tokens)
{
	string::size_type lastPos = s.find_first_not_of(delimiters, 0);
	string::size_type pos = s.find_first_of(delimiters, lastPos);
	while (string::npos != pos || string::npos != lastPos)
	{
		tokens.push_back(s.substr(lastPos, pos - lastPos));
		lastPos = s.find_first_not_of(delimiters, pos);
		pos = s.find_first_of(delimiters, lastPos);
	}
}

vector<string> StringUtil::Tokenize(const string& s, const string& delimiters)
{
	vector<string> tokens;
	Tokenize(s, delimiters, tokens);
	return tokens;
}

PlanetWars::PlanetWars(const string& gameState, uint iTurmNumber)
	: m_iTurnNumber(iTurmNumber)
{
	ParseGameState(gameState);

	ComputeData();
}

int PlanetWars::GetPlanetsCount() const
{
	return m_aPlanets.size();
}

const Planet& PlanetWars::GetPlanet(int planet_id) const
{
	return m_aPlanets[planet_id];
}

Planet& PlanetWars::GetPlanet(int planet_id)
{
	return m_aPlanets[planet_id];
}

int PlanetWars::GetFleetsCount() const
{
	return m_aFleets.size();
}

const Fleet& PlanetWars::GetFleet(int fleet_id) const
{
	return m_aFleets[fleet_id];
}

string PlanetWars::ToString() const
{
	stringstream s;
	for (unsigned int i = 0; i < m_aPlanets.size(); ++i)
	{
		const Planet& p = m_aPlanets[i];
		s << "P " << p.GetX() << " " << p.GetY() << " " << p.GetOwner()
			<< " " << p.GetShipsCount() << " " << p.GetGrowthRate() << endl;
	}
	for (unsigned int i = 0; i < m_aFleets.size(); ++i)
	{
		const Fleet& f = m_aFleets[i];
		s << "F " << f.GetOwner() << " " << f.GetShipsCount() << " "
			<< f.GetSourcePlanet() << " " << f.GetDestinationPlanet() << " "
			<< f.GetTotalTripLength() << " " << f.GetTurnsRemaining() << endl;
	}
	return s.str();
}

int PlanetWars::GetDistance(int source_planet, int destination_planet) const
{
	const Planet& source = m_aPlanets[source_planet];
	const Planet& destination = m_aPlanets[destination_planet];
	double dx = source.GetX() - destination.GetX();
	double dy = source.GetY() - destination.GetY();
	return (int)ceil(sqrt(dx * dx + dy * dy));
}

void PlanetWars::IssueOrder(int source_planet, int destination_planet, int num_ships)
{
	LOG("IssueOrder : (%3d -> %3d) [%3d]\n", source_planet, destination_planet, num_ships);

	CHECK_RETURN(GetPlanet(source_planet).GetOwner() == 1, "Bad Source Planet\n");
	CHECK_RETURN(source_planet != destination_planet, "Same Planet\n");
	CHECK_RETURN(GetPlanet(source_planet).GetShipsCount() >= num_ships, "Too many Ship (%d pour %d)\n", num_ships, GetPlanet(source_planet).GetShipsCount());
	CHECK_RETURN(num_ships > 0, "Negative ship count\n");

	cout << source_planet << " " << destination_planet << " " << num_ships << endl;
	cout.flush();

	int iDist = GetDistance(source_planet, destination_planet);
	m_aFleets.push_back(Fleet(1, num_ships, source_planet, destination_planet, iDist, iDist));
	
	Planet& DestPlanet = GetPlanet(destination_planet);
	DestPlanet.AddFleet(&(m_aFleets.back()), m_aFleets.size()-1);
	DestPlanet.Compute(*this);

	Planet& SrcPlanet = GetPlanet(source_planet);
	SrcPlanet.RemoveShips(num_ships);
	SrcPlanet.Compute(*this);
}

void PlanetWars::FinishTurn() const
{
	cout << "go" << endl;
	cout.flush();
}


bool PlanetWars::IsAlive(int player_id) const
{
	for (unsigned int i = 0; i < m_aPlanets.size(); ++i)
	{
		if (m_aPlanets[i].GetOwner() == player_id)
		{
			return true;
		}
	}
	for (unsigned int i = 0; i < m_aFleets.size(); ++i)
	{
		if (m_aFleets[i].GetOwner() == player_id)
		{
			return true;
		}
	}
	return false;
}

int PlanetWars::ParseGameState(const string& s)
{
	m_aPlanets.clear();
	m_aFleets.clear();
	vector<string> lines = StringUtil::Tokenize(s, "\n");
	int planet_id = 0;
	for (unsigned int i = 0; i < lines.size(); ++i)
	{
		string& line = lines[i];
		size_t comment_begin = line.find_first_of('#');
		if (comment_begin != string::npos)
		{
			line = line.substr(0, comment_begin);
		}
		vector<string> tokens = StringUtil::Tokenize(line);
		if (tokens.size() == 0)
		{
			continue;
		}

		if (tokens[0] == "P")
		{
			if (tokens.size() != 6)
			{
				return 0;
			}
			Planet p(planet_id++,              // The ID of this planet
				atoi(tokens[3].c_str()),  // Owner
				atoi(tokens[4].c_str()),  // Num ships
				atoi(tokens[5].c_str()),  // Growth rate
				atof(tokens[1].c_str()),  // X
				atof(tokens[2].c_str())); // Y
			m_aPlanets.push_back(p);
		}
		else if (tokens[0] == "F")
		{
			if (tokens.size() != 7)
			{
				return 0;
			}
			Fleet f(atoi(tokens[1].c_str()),  // Owner
				atoi(tokens[2].c_str()),  // Num ships
				atoi(tokens[3].c_str()),  // Source
				atoi(tokens[4].c_str()),  // Destination
				atoi(tokens[5].c_str()),  // Total trip length
				atoi(tokens[6].c_str())); // Turns remaining
			m_aFleets.push_back(f);
		}
		else
		{
			return 0;
		}
	}
	return 1;
}

void PlanetWars::ComputeData()
{
	for (uint i=0 ; i<m_aPlanets.size() ; ++i)
	{
		switch (m_aPlanets[i].GetOwner())
		{
			case 0:
				m_aNeutralPlanets.push_back(&m_aPlanets[i]);
				m_aNotOwnedPlanets.push_back(&m_aPlanets[i]);
				break;

			case 1:
				m_aOwnedPlanets.push_back(&m_aPlanets[i]);
				break;

			case 2:
				m_aEnemyPlanets.push_back(&m_aPlanets[i]);
				m_aNotOwnedPlanets.push_back(&m_aPlanets[i]);
				break;
		}
	}

	for (uint i=0 ; i<m_aFleets.size() ; ++i)
	{
		switch (m_aFleets[i].GetOwner())
		{
		case 0:
			break;

		case 1:
			m_aOwnedFleets.push_back(&m_aFleets[i]);
			break;

		case 2:
			m_aEnemyFleets.push_back(&m_aFleets[i]);
			break;
		}

		Planet& DestPlanet = GetPlanet(m_aFleets[i].GetDestinationPlanet());
		DestPlanet.AddFleet(&m_aFleets[i], i);

		/*
		if (DestPlanet.GetOwner() == m_aFleets[i].GetOwner())
			DestPlanet.AddPotentialShips(m_aFleets[i].GetShipsCount());
		else
			DestPlanet.RemovePotentialShips(m_aFleets[i].GetShipsCount());

		if (DestPlanet.GetPotentialShipsCount() < 0)
			DestPlanet.SetPotentialOwner(m_aFleets[i].GetOwner());
			*/
	}

	for (uint i=0 ; i<m_aPlanets.size() ; ++i)
		m_aPlanets[i].Compute(*this);

}

