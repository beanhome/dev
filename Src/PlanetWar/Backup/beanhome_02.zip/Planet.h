#ifndef __PLANET_H__
#define __PLANET_H__

#include <vector>

class PlanetWars;
class Fleet;

struct NextTurn
{
	int m_iOwner;
	int m_iShipCount;
	vector<uint> m_aFleets;

	NextTurn()
		: m_iOwner(0)
		, m_iShipCount(0)
	{}
};

class Planet
{
	public:
		// Initializes a planet.
		Planet(int planet_id,
			int owner,
			int num_ships,
			int growth_rate,
			double x,
			double y);

		// Returns the ID of this planets. Planets are numbered starting at zero.
		int GetPlanetID() const { return m_iPlanetId; }

		// Returns the ID of the player that owns this planet. Your playerID is
		// always 1. If the owner is 1, this is your planet. If the owner is 0, then
		// the planet is neutral. If the owner is 2 or some other number, then this
		// planet belongs to the enemy.
		int GetOwner(uint iTurn=0) const; // { return m_iOwner; }

		// The number of ships on the planet. This is the "population" of the planet.
		int GetShipsCount(uint iTurn=0) const; // { return m_iShipsCount; }

		// Returns the growth rate of the planet. Unless the planet is neutral, the
		// population of the planet grows by this amount each turn. The higher this
		// number is, the faster this planet produces ships.
		int GetGrowthRate() const { return m_iGrowthRate; }

		// The position of the planet in space.
		double GetX() const { return m_fX; }
		double GetY() const { return m_fY; }


		const NextTurn& GetNextTurn(uint i) const { return m_aNextTurn[i]; }

		// Use the following functions to set the properties of this planet. Note
		// that these functions only affect your program's copy of the game state.
		// You can't steal your opponent's planets just by changing the owner to 1
		// using the Owner(int) function! :-)
		//void SetOwner(int new_owner) { m_iOwner = new_owner; }
		//void SetShipsCount(int new_num_ships) { m_iShipsCount = new_num_ships; }

		//void AddShips(int amount);
		void RemoveShips(int amount);

		void ApplyFleet(int iOwner, uint iAmount, uint iTurn);

		void AddFleet(Fleet* pFleet, uint iFleetID);
		void Compute(PlanetWars& pw);

		bool IsLosingOwner(uint& iLosingTurn);

	private:
		int				m_iPlanetId;
		int				m_iGrowthRate;
		double			m_fX;
		double			m_fY;

		int				m_iOwner;
		int				m_iShipsCount;

		NextTurn		m_aNextTurn[MAX_TURN];
};


#endif
