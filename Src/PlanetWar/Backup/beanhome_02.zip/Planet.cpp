
#include "Utils.h"
#include "Planet.h"
#include "Fleet.h"
#include <assert.h>
#include "PlanetWars.h"


Planet::Planet(int planet_id, int owner, int num_ships, int growth_rate, double x, double y)
	: m_iPlanetId(planet_id)
	, m_iGrowthRate(growth_rate)
	, m_fX(x)
	, m_fY(y)
	, m_iOwner(owner)
	, m_iShipsCount(num_ships)
{
	m_aNextTurn[0].m_iOwner = m_iOwner;
	m_aNextTurn[0].m_iShipCount = m_iShipsCount;
}

int Planet::GetOwner(uint iTurn) const
{
	assert(iTurn < MAX_TURN);
	return m_aNextTurn[iTurn].m_iOwner;
}


int Planet::GetShipsCount(uint iTurn) const
{
	assert(iTurn < MAX_TURN);
	return m_aNextTurn[iTurn].m_iShipCount;
}


void Planet::AddFleet(Fleet* pFleet, uint iFleetId)
{
	assert(pFleet->GetTurnsRemaining() < MAX_TURN);
	assert(pFleet->GetDestinationPlanet() == GetPlanetID());

	m_aNextTurn[pFleet->GetTurnsRemaining()].m_aFleets.push_back(iFleetId);
}

void Planet::Compute(PlanetWars& pw)
{
	CHECK(m_aNextTurn[0].m_aFleets.size() == 0 , "m_aNextTurn[0].m_aFleets not empty\n");

	for (uint i=1 ; i<MAX_TURN ; ++i)
	{
		NextTurn& oNextTurn = m_aNextTurn[i];
		NextTurn& oPrevTurn = m_aNextTurn[i-1];
		
		oNextTurn.m_iOwner = oPrevTurn.m_iOwner;
		oNextTurn.m_iShipCount = oPrevTurn.m_iShipCount;

		if (oNextTurn.m_iOwner > 0)
			oNextTurn.m_iShipCount += GetGrowthRate();

		for (uint j=0 ; j<oNextTurn.m_aFleets.size() ; ++j)
		{
			const Fleet& oFleet = pw.GetFleet(oNextTurn.m_aFleets[j]);

			if (oFleet.GetOwner() == oNextTurn.m_iOwner)
			{
				oNextTurn.m_iShipCount += oFleet.GetShipsCount();
			}
			else
			{
				oNextTurn.m_iShipCount -= oFleet.GetShipsCount();

				if (oNextTurn.m_iShipCount < 0)
				{
					oNextTurn.m_iOwner = oFleet.GetOwner();
					oNextTurn.m_iShipCount = -oNextTurn.m_iShipCount;
				}
			}
		}
	}
}



/*
void Planet::AddShips(int amount)
{
	LOG("Add Ship\n");
	m_iShipsCount += amount;
}
*/

void Planet::RemoveShips(int amount)
{
	//m_iShipsCount -= amount;
	m_aNextTurn[0].m_iShipCount -= amount;
}

bool Planet::IsLosingOwner(uint& iLosingTurn)
{
	for (uint i=0 ; i<MAX_TURN ; ++i)
	{
		if (m_aNextTurn[i].m_iOwner == 2)
		{
			iLosingTurn = i;
			return true;
		}
	}

	return false;
}


