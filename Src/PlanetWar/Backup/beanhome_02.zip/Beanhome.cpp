#include <iostream>
#include <vector>

#include "Utils.h"
#include "PlanetWars.h"
#include "Planet.h"
#include "Fleet.h"

#ifdef MYDEBUG
void PrintPlanet(char* sTitle, const PlanetWars& pw);
#endif

void DoTurn(PlanetWars& pw) 
{
	LOG("Turn %d\n\n", pw.GetTurnNumber());

#ifdef MYDEBUG
	PrintPlanet("Pre Order :", pw);
#endif

	const vector<Planet*>& MyPlanet = pw.GetOwnedPlanets();
	for (uint i=0 ; i<MyPlanet.size() ; ++i)
	{
		uint iTurnCount;
		if (MyPlanet[i]->IsLosingOwner(iTurnCount))
			continue;

		for (uint j=0 ; j<MyPlanet.size() ; ++j)
		{
			if (i!=j && MyPlanet[j]->IsLosingOwner(iTurnCount))
			{
				int iShipCount = (MyPlanet[j]->GetShipsCount(iTurnCount) + 1);
				if (iShipCount > MyPlanet[i]->GetShipsCount() / 2)
					iShipCount = MyPlanet[i]->GetShipsCount() / 2;

				if (iShipCount > MyPlanet[i]->GetShipsCount())
					iShipCount = MyPlanet[i]->GetShipsCount() - 1;

				if (iShipCount > 0)
					pw.IssueOrder(MyPlanet[i]->GetPlanetID(), MyPlanet[j]->GetPlanetID(), iShipCount);
			}
		}

		const vector<Planet*>& OtherPlanet = pw.GetNotOwnedPlanets();
		uint iBestId = (uint)-1;
		int iBestDist = 100;

		for (uint j=0 ; j<OtherPlanet.size() ; ++j)
		{
			int iDist = pw.GetDistance(OtherPlanet[j]->GetPlanetID(), MyPlanet[i]->GetPlanetID());

			if (OtherPlanet[j]->GetOwner(iDist) == 1)
				continue;

			if (OtherPlanet[j]->GetShipsCount() > 0
			 && OtherPlanet[j]->GetShipsCount(iDist) <= 0)
				continue;

			if (OtherPlanet[j]->GetShipsCount(iDist) + 1 < MyPlanet[i]->GetShipsCount(iDist) / 2
			 && OtherPlanet[j]->GetShipsCount(iDist) + 1 < MyPlanet[i]->GetShipsCount()
			 || MyPlanet[i]->GetShipsCount() > 200)
			{
				if (iBestId == (uint)-1 || iDist < iBestDist)
				{
					iBestId = OtherPlanet[j]->GetPlanetID();
					iBestDist = iDist;
				}
			}
		}

		if (iBestId != (uint)-1)
		{
			int iDist = pw.GetDistance(iBestId, MyPlanet[i]->GetPlanetID());
			int ShipCount = pw.GetPlanet(iBestId).GetShipsCount(iDist) + 1;
			if (MyPlanet[i]->GetShipsCount() > ShipCount)
				pw.IssueOrder(MyPlanet[i]->GetPlanetID(), iBestId, ShipCount);
		}
	}

	LOG("\n");
#ifdef MYDEBUG
	PrintPlanet("Post Order :", pw);
#endif

	LOG("\n");
}

#ifdef MYDEBUG
void PrintPlanet(char* sTitle, const PlanetWars& pw)
{
	const int iTitleSize = 36;

	if (strlen(sTitle) > iTitleSize)
		sTitle[iTitleSize] = 0;

	const uint iNextTurnLog = (g_bVisualDebug ? 5 : MAX_TURN);
	
	LOG("%-*s", iTitleSize, sTitle);
	for (uint j=0 ; j<iNextTurnLog ; ++j)
		LOG("%3d      ", pw.GetTurnNumber() + j);
	LOG("\n");

	const vector<Planet>& AllPlanet = pw.GetAllPlanets();
	for (uint i=0 ; i<AllPlanet.size() ; ++i)
	{
		LOG("Planet %2d : (%d) %7.3f %7.3f", AllPlanet[i].GetPlanetID(), AllPlanet[i].GetGrowthRate(), AllPlanet[i].GetX(), AllPlanet[i].GetY());
		for (uint j=0 ; j<iNextTurnLog ; ++j)
		{
			LOG("  | %d %3d", AllPlanet[i].GetNextTurn(j).m_iOwner, AllPlanet[i].GetNextTurn(j).m_iShipCount);
		}
		LOG("\n");

		/*
		LOG("Planet %2d : %3d [%3d]   (%3d) %3.3f %3.3f \t\t %3d [%3d]\n",
			AllPlanet[i].GetPlanetID(), AllPlanet[i].GetOwner(), AllPlanet[i].GetShipsCount(), AllPlanet[i].GetGrowthRate(), AllPlanet[i].GetX(), AllPlanet[i].GetY(),
			AllPlanet[i].GetNextTurn(1).m_iOwner, AllPlanet[i].GetNextTurn(1).m_iShipCount);
		*/
		for (uint j=0 ; j<MAX_TURN ; ++j)
		{
			const vector<uint>& aFleetsID = AllPlanet[i].GetNextTurn(j).m_aFleets;
			for (uint k=0 ; k<aFleetsID.size() ; ++k)
			{
				const Fleet& oFleet = pw.GetFleet(aFleetsID[k]);
				LOG("\t Fleet : %3d (%3d -> %3d) [%3d] (%2u/%2d)\n", oFleet.GetOwner(), oFleet.GetSourcePlanet(), oFleet.GetDestinationPlanet(), oFleet.GetShipsCount(), oFleet.GetTurnsRemaining(), oFleet.GetTotalTripLength());
			}
		}
	}
}
#endif

