#ifndef __UTILS_H__
#define __UTILS_H__

#include <stdio.h>
#include <vector>
using namespace std;

#ifdef _DEBUG
#define MYDEBUG
#endif

#ifdef MYDEBUG
extern bool  g_bVisualDebug;
extern FILE* g_MyLog;
#define LOG(format, ...) fprintf(g_MyLog, format, __VA_ARGS__); fflush(g_MyLog)
#define CHECK(test, format, ...) if (!(test)) { LOG(format, __VA_ARGS__); }
#define CHECK_RETURN(test, format, ...) if (!(test)) { LOG(format, __VA_ARGS__); return; }
#else
#define LOG(format, ...) 
#define CHECK(test, format, ...)
#define CHECK_RETURN(test, format, ...) if (!(test)) return 
#endif


typedef unsigned int uint;

#define MAX_TURN 50

#endif // __UTILS_H__
