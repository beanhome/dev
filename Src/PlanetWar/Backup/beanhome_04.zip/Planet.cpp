
#include "Utils.h"
#include "Planet.h"
#include "Fleet.h"
#include <assert.h>
#include "PlanetWars.h"


Planet::Planet(int planet_id, int owner, int num_ships, int growth_rate, double x, double y)
	: m_iPlanetId(planet_id)
	, m_iGrowthRate(growth_rate)
	, m_fX(x)
	, m_fY(y)
	, m_iOwner(owner)
	, m_iShipsCount(num_ships)
{
	m_aNextTurn[0].m_iOwner = m_iOwner;
	m_aNextTurn[0].m_iShipCount = m_iShipsCount;
}

int Planet::GetOwner(uint iTurn) const
{
	assert(iTurn < MAX_TURN);
	return m_aNextTurn[iTurn].m_iOwner;
}


int Planet::GetShipsCount(uint iTurn) const
{
	assert(iTurn < MAX_TURN);
	return m_aNextTurn[iTurn].m_iShipCount;
}


void Planet::AddFleet(const Fleet& oFleet)
{
	if (oFleet.GetSourcePlanet() == GetPlanetID())
	{
		if (oFleet.GetStartTurn() >= 0)
		{
			assert(oFleet.GetStartTurn() < MAX_TURN);
			m_aNextTurn[oFleet.GetStartTurn()].m_aFleets.insert(oFleet.GetID());
		}
	}
	else
	{
		CHECK(oFleet.GetDestinationPlanet() == GetPlanetID(), "Error : bad Fleet\n");

		if (oFleet.GetFinishTurn() >= 0)
		{
			assert(oFleet.GetFinishTurn() < MAX_TURN);
			m_aNextTurn[oFleet.GetFinishTurn()].m_aFleets.insert(oFleet.GetID());
		}
	}
}

void Planet::RemoveFleet(const Fleet& oFleet)
{
	if (oFleet.GetSourcePlanet() == GetPlanetID())
	{
		if (oFleet.GetStartTurn() >= 0)
		{
			assert(oFleet.GetStartTurn() < MAX_TURN);
			m_aNextTurn[oFleet.GetStartTurn()].m_aFleets.erase(oFleet.GetID());
		}
	}
	else
	{
		CHECK(oFleet.GetDestinationPlanet() == GetPlanetID(), "Error : bad Fleet\n");

		if (oFleet.GetFinishTurn() >= 0)
		{
			assert(oFleet.GetFinishTurn() < MAX_TURN);
			m_aNextTurn[oFleet.GetFinishTurn()].m_aFleets.erase(oFleet.GetID());
		}
	}
}

void Planet::Compute(PlanetWars& pw)
{
	for (uint i=0 ; i<MAX_TURN ; ++i)
	{
		NextTurn& oNextTurn = m_aNextTurn[i];

		if (i > 0)
		{
			NextTurn& oPrevTurn = m_aNextTurn[i-1];
			oNextTurn.m_iOwner = oPrevTurn.m_iOwner;
			oNextTurn.m_iShipCount = oPrevTurn.m_iShipCount;
			
			if (oNextTurn.m_iOwner > 0)
				oNextTurn.m_iShipCount += GetGrowthRate();
		}
		else
		{
			oNextTurn.m_iOwner = m_iOwner;
			oNextTurn.m_iShipCount = m_iShipsCount;
		}
		
		set<uint>::const_iterator begin = oNextTurn.m_aFleets.begin();
		set<uint>::const_iterator end = oNextTurn.m_aFleets.end();
		set<uint>::const_iterator it;

		for (it = begin ; it != end ; ++it)
		{
			const Fleet& oFleet = pw.GetFleet(*it);

			if (oFleet.GetSourcePlanet() == GetPlanetID())
			{
				if (oFleet.GetOwner() == oNextTurn.m_iOwner)
				{
					oNextTurn.m_iShipCount -= oFleet.GetShipsCount();
				}
				else
				{
					LOG("Error : Start Fleet from unowned Planet\n");
					assert(false);
				}
			}
			else
			{
				CHECK(oFleet.GetDestinationPlanet() == GetPlanetID(), "Error : Bad Planet\n");
				if (oFleet.GetOwner() == oNextTurn.m_iOwner)
				{
					oNextTurn.m_iShipCount += oFleet.GetShipsCount();
				}
				else
				{
					oNextTurn.m_iShipCount -= oFleet.GetShipsCount();

					if (oNextTurn.m_iShipCount < 0)
					{
						oNextTurn.m_iOwner = oFleet.GetOwner();
						oNextTurn.m_iShipCount = -oNextTurn.m_iShipCount;
					}
				}

			}

		}
	}
}



/*
void Planet::AddShips(int amount)
{
	LOG("Add Ship\n");
	m_iShipsCount += amount;
}
*/

void Planet::RemoveRealShips(int amount)
{
	m_iShipsCount -= amount;
}

void Planet::RemoveShips(int amount)
{
	//m_iShipsCount -= amount;
	m_aNextTurn[0].m_iShipCount -= amount;
}

bool Planet::IsLosingOwner(uint& iLosingTurn) const
{
	for (uint i=1 ; i<MAX_TURN ; ++i)
	{
		if (m_aNextTurn[i].m_iOwner != m_aNextTurn[i-1].m_iOwner)
		{
			iLosingTurn = i;
			return true;
		}
	}

	return false;
}

#ifdef MYDEBUG
void Planet::Log(const PlanetWars& pw, uint iNextTurnLog) const
{
	LOG("Planet %2d : (%d) %7.3f %7.3f", GetPlanetID(), GetGrowthRate(), GetX(), GetY());
	for (uint j=0 ; j<iNextTurnLog ; ++j)
	{
		LOG("  | %d %3d", GetNextTurn(j).m_iOwner, GetNextTurn(j).m_iShipCount);
	}
	LOG("\n");

	for (uint j=0 ; j<MAX_TURN ; ++j)
	{
		const set<uint>& aFleetsID = GetNextTurn(j).m_aFleets;

		set<uint>::const_iterator begin = aFleetsID.begin();
		set<uint>::const_iterator end = aFleetsID.end();
		set<uint>::const_iterator it;

		for (it = begin ; it != end ; ++it)
		{
			LOG("\t ");
			pw.GetFleet(*it).Log();
		}
	}

}
#endif
