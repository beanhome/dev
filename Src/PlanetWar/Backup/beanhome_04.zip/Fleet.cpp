
#include "Utils.h"
#include "Fleet.h"

Fleet::Fleet()
	: m_iId((uint)-1)
	, m_iOwner(0)
	, m_iShipsCount(0)
	, m_iSourcePlanet(0)
	, m_iDestinationPlanet(0)
	, m_iStartTurn(0)
	, m_iTotalTripLength(0)
	, m_iTurnsRemaining(0)
{
}

Fleet::Fleet(uint iId, uint owner, uint num_ships, uint source_planet, uint destination_planet, int start_turn, uint total_trip_length, uint turns_remaining)
	: m_iId(iId)
	, m_iOwner(owner)
	, m_iShipsCount(num_ships)
	, m_iSourcePlanet(source_planet)
	, m_iDestinationPlanet(destination_planet)
	, m_iStartTurn(start_turn)
	, m_iTotalTripLength(total_trip_length)
	, m_iTurnsRemaining(turns_remaining)
{
}

#ifdef MYDEBUG
void Fleet::Log() const
{
	LOG("Fleet : %3d (%3d -> %3d) [%3d] (%2i/%2u/%2d)\n", GetOwner(), GetSourcePlanet(), GetDestinationPlanet(), GetShipsCount(), GetStartTurn(), GetTurnsRemaining(), GetTotalTripLength());
}
#endif

