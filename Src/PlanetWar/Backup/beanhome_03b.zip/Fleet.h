#ifndef __FLEET_H__
#define __FLEET_H__

#include "Utils.h"

class Fleet
{
	public:
		// Initializes a fleet.
		Fleet(uint iId, uint owner, uint num_ships, uint source_planet, uint destination_planet, int start_turn, uint total_trip_length, uint turns_remaining);

		uint GetID() const { return m_iId; }

		uint GetOwner() const { return m_iOwner; }

		uint GetShipsCount() const { return m_iShipsCount; }

		uint GetSourcePlanet() const { return m_iSourcePlanet; }

		uint GetDestinationPlanet() const { return m_iDestinationPlanet; }

		uint GetTotalTripLength() const { return m_iTotalTripLength; }

		void Cancel() { m_bCanceled = true; }
		bool IsCanceled() const { return m_bCanceled; }

		// Returns the number of turns until this fleet reaches its destination. If
		// this value is 1, then the fleet will hit the destination planet next turn.
		uint GetTurnsRemaining() const { return m_iTurnsRemaining; }

		int GetStartTurn() const { return m_iStartTurn; }
		int GetFinishTurn() const { return m_iStartTurn + m_iTotalTripLength; }

#ifdef MYDEBUG
		void Log() const;
#endif

	private:
		uint 				m_iId;
		uint 				m_iOwner;
		uint				m_iShipsCount;
		uint				m_iSourcePlanet;
		uint				m_iDestinationPlanet;
		int					m_iStartTurn;
		uint				m_iTotalTripLength;
		uint				m_iTurnsRemaining;
		bool				m_bCanceled;
};

#endif
