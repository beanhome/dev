#ifndef __TIME_H__
#define __TIME_H__

#include "Utils.h"

extern uint GetTime();
extern uint GetDelta(uint t1, uint t2);

#endif // __TIME_H__
