#include "PlanetWars.h"
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

void StringUtil::Tokenize(const string& s, const string& delimiters, vector<string>& tokens)
{
	string::size_type lastPos = s.find_first_not_of(delimiters, 0);
	string::size_type pos = s.find_first_of(delimiters, lastPos);
	while (string::npos != pos || string::npos != lastPos)
	{
		tokens.push_back(s.substr(lastPos, pos - lastPos));
		lastPos = s.find_first_not_of(delimiters, pos);
		pos = s.find_first_of(delimiters, lastPos);
	}
}

vector<string> StringUtil::Tokenize(const string& s, const string& delimiters)
{
	vector<string> tokens;
	Tokenize(s, delimiters, tokens);
	return tokens;
}

PlanetWars::PlanetWars(const string& gameState, uint iTurmNumber)
	: m_iTurnNumber(iTurmNumber)
{
	ParseGameState(gameState);

	ComputeData();
}

const Planet& PlanetWars::GetPlanet(int planet_id) const
{
	return m_aPlanets[planet_id];
}

Planet& PlanetWars::GetPlanet(int planet_id)
{
	return m_aPlanets[planet_id];
}

const Fleet& PlanetWars::GetFleet(int fleet_id) const
{
	return m_aFleets[fleet_id];
}

int PlanetWars::GetDistance(int source_planet, int destination_planet) const
{
	const Planet& source = m_aPlanets[source_planet];
	const Planet& destination = m_aPlanets[destination_planet];
	double dx = source.GetX() - destination.GetX();
	double dy = source.GetY() - destination.GetY();
	return (int)ceil(sqrt(dx * dx + dy * dy));
}

void PlanetWars::AddPlanet(uint iId, uint iOwner, uint iShipCount, uint iGrowthRate, float fX, float fY)
{
	Planet p(iId, iOwner, iShipCount, iGrowthRate, fX, fY);
	m_aPlanets.push_back(p);
}


void PlanetWars::AddFleet(uint iOwner, uint ishipCount, uint iSourcePlanet, uint iDestinationPlanet, uint iTotalTripLength, uint iTurnsRemaining)
{
	uint Id = m_aFleets.size();
	int iStartTurn = iTurnsRemaining - iTotalTripLength;

	Fleet oFleet(Id, iOwner, ishipCount, iSourcePlanet, iDestinationPlanet, iStartTurn, iTotalTripLength, iTurnsRemaining);
	m_aFleets.push_back(oFleet);

	Planet& SrcPlanet = GetPlanet(oFleet.GetSourcePlanet());
	SrcPlanet.AddFleet(oFleet);

	Planet& DstPlanet = GetPlanet(oFleet.GetDestinationPlanet());
	DstPlanet.AddFleet(oFleet);
}

uint PlanetWars::CreateFleet(uint iOwner, uint ishipCount, uint iSourcePlanet, uint iDestinationPlanet, uint iStartTurn)
{
	uint Id = m_aFleets.size();
	uint iTotalTripLength = GetDistance(iSourcePlanet, iDestinationPlanet);
	uint iTurnsRemaining = iTotalTripLength;

	Fleet oFleet(Id, iOwner, ishipCount, iSourcePlanet, iDestinationPlanet, iStartTurn, iTotalTripLength, iTurnsRemaining);

	m_aFleets.push_back(oFleet);

	Planet& SrcPlanet = GetPlanet(oFleet.GetSourcePlanet());
	SrcPlanet.AddFleet(oFleet);
	SrcPlanet.Compute(*this);

	Planet& DstPlanet = GetPlanet(oFleet.GetDestinationPlanet());
	DstPlanet.AddFleet(oFleet);
	DstPlanet.Compute(*this);

	return oFleet.GetID();
}

void PlanetWars::RemoveFleet(uint id)
{
	Fleet& oFleet = m_aFleets[id];

	oFleet.Cancel();

	Planet& SrcPlanet = GetPlanet(oFleet.GetSourcePlanet());
	SrcPlanet.RemoveFleet(oFleet);
	SrcPlanet.Compute(*this);

	Planet& DstPlanet = GetPlanet(oFleet.GetDestinationPlanet());
	DstPlanet.RemoveFleet(oFleet);
	DstPlanet.Compute(*this);

}

/*
void PlanetWars::CreateOrder(int iSourcePlanet, int iDestinationPlanet, int iShipCount)
{	
	int iDist = GetDistance(iSourcePlanet, iDestinationPlanet);
	Fleet oFleet(1, iShipCount, iSourcePlanet, iDestinationPlanet, iDist, iDist, Test);

	AddFleet(oFleet);
}
*/

void PlanetWars::IssueOrder(int source_planet, int destination_planet, int num_ships) const
{
	LOG("IssueOrder : (%3d -> %3d) [%3d]\n", source_planet, destination_planet, num_ships);

	CHECK_RETURN(GetPlanet(source_planet).GetOwner() == 1, "Bad Source Planet\n");
	CHECK_RETURN(source_planet != destination_planet, "Same Planet\n");
	CHECK_RETURN(GetPlanet(source_planet).GetRealShipsCount() >= num_ships, "Too many Ship (%d pour %d)\n", num_ships, GetPlanet(source_planet).GetRealShipsCount());
	CHECK_RETURN(num_ships > 0, "Negative ship count\n");

	cout << source_planet << " " << destination_planet << " " << num_ships << endl;
	cout.flush();
}

void PlanetWars::ExecuteOrders()
{
	for (uint i=0 ; i<m_aFleets.size() ; ++i)
	{
		if (m_aFleets[i].GetStartTurn() == 0 && m_aFleets[i].IsCanceled() == false)
		{
			IssueOrder(m_aFleets[i].GetSourcePlanet(), m_aFleets[i].GetDestinationPlanet(), m_aFleets[i].GetShipsCount());

			GetPlanet(m_aFleets[i].GetSourcePlanet()).RemoveRealShips(m_aFleets[i].GetShipsCount());
		}
	}
}


void PlanetWars::FinishTurn() const
{
	cout << "go" << endl;
	cout.flush();
}


bool PlanetWars::IsAlive(int player_id) const
{
	for (unsigned int i = 0; i < m_aPlanets.size(); ++i)
	{
		if (m_aPlanets[i].GetOwner() == player_id)
		{
			return true;
		}
	}
	for (unsigned int i = 0; i < m_aFleets.size(); ++i)
	{
		if (m_aFleets[i].GetOwner() == player_id)
		{
			return true;
		}
	}
	return false;
}

int PlanetWars::ParseGameState(const string& s)
{
	m_aPlanets.clear();
	m_aFleets.clear();
	vector<string> lines = StringUtil::Tokenize(s, "\n");
	int planet_id = 0;
	for (unsigned int i = 0; i < lines.size(); ++i)
	{
		string& line = lines[i];
		size_t comment_begin = line.find_first_of('#');
		if (comment_begin != string::npos)
		{
			line = line.substr(0, comment_begin);
		}
		vector<string> tokens = StringUtil::Tokenize(line);
		if (tokens.size() == 0)
		{
			continue;
		}

		if (tokens[0] == "P")
		{
			if (tokens.size() != 6)
			{
				return 0;
			}

			AddPlanet(planet_id++,        // The ID of this planet
				atoi(tokens[3].c_str()),  // Owner
				atoi(tokens[4].c_str()),  // Num ships
				atoi(tokens[5].c_str()),  // Growth rate
				(float)atof(tokens[1].c_str()),  // X
				(float)atof(tokens[2].c_str())); // Y
		}
		else if (tokens[0] == "F")
		{
			if (tokens.size() != 7)
			{
				return 0;
			}

			AddFleet(atoi(tokens[1].c_str()),  // Owner
				atoi(tokens[2].c_str()),       // Num ships
				atoi(tokens[3].c_str()),       // Source
				atoi(tokens[4].c_str()),       // Destination
				atoi(tokens[5].c_str()),       // Total trip length
				atoi(tokens[6].c_str()));      // Turns remaining
		}
		else
		{
			return 0;
		}
	}
	return 1;
}

void PlanetWars::ComputeData()
{
	for (uint i=0 ; i<m_aPlanets.size() ; ++i)
	{
		switch (m_aPlanets[i].GetOwner())
		{
			case 0:
				m_aNeutralPlanets.push_back(&m_aPlanets[i]);
				m_aNotOwnedPlanets.push_back(&m_aPlanets[i]);
				break;

			case 1:
				m_aOwnedPlanets.push_back(&m_aPlanets[i]);
				break;

			case 2:
				m_aEnemyPlanets.push_back(&m_aPlanets[i]);
				m_aNotOwnedPlanets.push_back(&m_aPlanets[i]);
				break;
		}

		m_aPlanets[i].Compute(*this);
	}
}

