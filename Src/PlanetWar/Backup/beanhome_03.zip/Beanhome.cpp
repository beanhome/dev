#include <iostream>
#include <vector>

#include "Utils.h"
#include "PlanetWars.h"
#include "Planet.h"
#include "Fleet.h"

#ifdef MYDEBUG
void PrintPlanet(char* sTitle, const PlanetWars& pw);
#endif

void DoTurn(PlanetWars& pw) 
{
	LOG("Turn %d\n\n", pw.GetTurnNumber());

#ifdef MYDEBUG
	PrintPlanet("Pre Order :", pw);
#endif

	const vector<Planet*>& AllMyPlanet = pw.GetOwnedPlanets();
	for (uint i=0 ; i<AllMyPlanet.size() ; ++i)
	{
		Planet& oPlanet = *AllMyPlanet[i];

		uint iTurnCount;
		if (oPlanet.IsLosingOwner(iTurnCount))
			continue;

		for (uint j=0 ; j<AllMyPlanet.size() ; ++j)
		{
			if (i == j)
				continue;

			Planet& oOtherPlanet = *AllMyPlanet[j];

			uint iDist = pw.GetDistance(oPlanet.GetPlanetID(), oOtherPlanet.GetPlanetID());

			if (oOtherPlanet.IsLosingOwner(iTurnCount) && iDist <= iTurnCount)
			{
				int iTargetCount = oOtherPlanet.GetShipsCount(iTurnCount) + 1;
				int iShipCount = min(oPlanet.GetShipsCount(), iTargetCount);

				while(iShipCount > 0)
				{
					uint iFleetID = pw.CreateFleet(1, iShipCount, oPlanet.GetPlanetID(), oOtherPlanet.GetPlanetID(), 0);

					if (oPlanet.IsLosingOwner(iTurnCount) == false)
						break;

					iShipCount -= (oPlanet.GetShipsCount(iTurnCount) + 1);
					pw.RemoveFleet(iFleetID);
				}
			}
		}

		const vector<Planet*>& OtherPlanet = pw.GetNotOwnedPlanets();
		uint iBestId = (uint)-1;
		float fBestPlanet = 0;

		for (uint j=0 ; j<OtherPlanet.size() ; ++j)
		{
			int iDist = pw.GetDistance(OtherPlanet[j]->GetPlanetID(), oPlanet.GetPlanetID());

			if (OtherPlanet[j]->GetOwner(iDist) == 1)
				continue;

			//if (oPlanet.GetShipsCount() < oPlanet.GetGrowthRate() * 10)
			//	continue;

			float fCurrentValue = (float)OtherPlanet[j]->GetGrowthRate();
			fCurrentValue /= (float)(iDist * iDist);
			fCurrentValue /= OtherPlanet[j]->GetShipsCount();

			if (iBestId == (uint)-1 || fCurrentValue > fBestPlanet)
			{
				iBestId = OtherPlanet[j]->GetPlanetID();
				fBestPlanet = fCurrentValue;
			}
		}

		if (iBestId != (uint)-1)
		{
			int iDist = pw.GetDistance(iBestId, oPlanet.GetPlanetID());

			int iTargetCount = pw.GetPlanet(iBestId).GetShipsCount(iDist) + 1;

			int iShipCount = min(oPlanet.GetShipsCount(), iTargetCount);

			while(iShipCount > 0)
			{
				uint iFleetID = pw.CreateFleet(1, iShipCount, oPlanet.GetPlanetID(), iBestId, 0);

				if (oPlanet.IsLosingOwner(iTurnCount) == false)
					break;

				iShipCount -= (oPlanet.GetShipsCount(iTurnCount) + 1);
				pw.RemoveFleet(iFleetID);
			}
		}
	}

	LOG("\n");
#ifdef MYDEBUG
	PrintPlanet("Post Order :", pw);
#endif

	LOG("\n");
}

#ifdef MYDEBUG
void PrintPlanet(char* sTitle, const PlanetWars& pw)
{
	const int iTitleSize = 36;
	const int iColumnSize = 9;

	if (strlen(sTitle) > iTitleSize)
		sTitle[iTitleSize] = 0;

	const uint iNextTurnLog = (g_bVisualDebug ? 5 : MAX_TURN);
	
	LOG("%-*s", iTitleSize, sTitle);
	for (uint j=0 ; j<iNextTurnLog ; ++j)
		LOG("%-*d", iColumnSize, pw.GetTurnNumber() + j);
	LOG("\n");

	const vector<Planet>& AllPlanet = pw.GetAllPlanets();
	for (uint i=0 ; i<AllPlanet.size() ; ++i)
	{
		AllPlanet[i].Log(pw, iNextTurnLog);
	}
}
#endif

