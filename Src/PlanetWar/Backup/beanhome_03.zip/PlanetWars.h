
#ifndef PLANET_WARS_H_
#define PLANET_WARS_H_

#include <string>
#include <vector>

#include "Utils.h"

#include "Planet.h"
#include "Fleet.h"

// This is a utility class that parses strings.
class StringUtil
{
	public:
		// Tokenizes a string s into tokens. Tokens are delimited by any of the
		// characters in delimiters. Blank tokens are omitted.
		static void Tokenize(const string& s, const string& delimiters, vector<string>& tokens);

		// A more convenient way of calling the Tokenize() method.
		static vector<string> Tokenize(const string& s, const string& delimiters = string(" "));
};


// Stores information about one planet. There is one instance of this class
// for each planet on the map.
class PlanetWars
{
	public:
		// Initializes the game state given a string containing game state data.
		PlanetWars(const string& game_state, uint iTurnNumber);

		uint GetTurnNumber() const { return m_iTurnNumber; }

		// Returns the planet with the given planet_id. There are NumPlanets()
		// planets. They are numbered starting at 0.
		const Planet& GetPlanet(int planet_id) const;
		Planet& GetPlanet(int planet_id);

		// Returns the fleet with the given fleet_id. Fleets are numbered starting
		// with 0. There are GetFleetsCount() fleets. fleet_id's are not consistent from
		// one turn to the next.
		const Fleet& GetFleet(int fleet_id) const;

		// Returns a list of all the planets.
		const vector<Planet>& GetAllPlanets() const { return m_aPlanets; }

		// Return a list of all the planets owned by the current player. By
		// convention, the current player is always player number 1.
		const vector<Planet*>& GetOwnedPlanets() const { return m_aOwnedPlanets; }

		// Return a list of all neutral planets.
		const vector<Planet*>& GetNeutralPlanets() const { return m_aNeutralPlanets; }

		// Return a list of all the planets owned by rival players. This excludes
		// planets owned by the current player, as well as neutral planets.
		const vector<Planet*>& GetEnemyPlanets() const { return m_aEnemyPlanets; }

		// Return a list of all the planets that are not owned by the current
		// player. This includes all enemy planets and neutral planets.
		const vector<Planet*>& GetNotOwnedPlanets() const { return m_aNotOwnedPlanets; }

		// Return a list of all the fleets.
		const vector<Fleet>& GetAllFleets() const { return m_aFleets; }

		// Returns the distance between two planets, rounded up to the next highest
		// integer. This is the number of discrete time steps it takes to get between
		// the two planets.
		int GetDistance(int source_planet, int destination_planet) const;

		// Sends an order to the game engine. The order is to send num_ships ships
		// from source_planet to destination_planet. The order must be valid, or
		// else your bot will get kicked and lose the game. For example, you must own
		// source_planet, and you can't send more ships than you actually have on
		// that planet.
		void IssueOrder(int source_planet, int destination_planet, int num_ships) const;

		// Sends a message to the game engine letting it know that you're done
		// issuing orders for now.
		void FinishTurn() const;

		void ExecuteOrders();

		// Returns true if the named player owns at least one planet or fleet.
		// Otherwise, the player is deemed to be dead and false is returned.
		bool IsAlive(int player_id) const;

		// Returns the number of ships that the given player has, either located
		// on planets or in flight.
		int GetTotalShipsCount(int player_id) const;


		void AddPlanet(uint iId, uint iOwner, uint iShipCount, uint iGrowthRate, float fX, float fY);
		void AddFleet(uint iOwner, uint ishipCount, uint iSourcePlanet, uint iDestinationPlanet, uint iTotalTripLength, uint iTurnsRemaining);
		uint CreateFleet(uint iOwner, uint ishipCount, uint iSourcePlanet, uint iDestinationPlanet, uint iStartTurn);
		void RemoveFleet(uint id);


	private:
		// Parses a game state from a string. On success, returns 1. On failure,
		// returns 0.
		int ParseGameState(const string& s);

		void ComputeData();


	private:
		uint m_iTurnNumber;

		vector<Planet> m_aPlanets;
		vector<Fleet> m_aFleets;

		vector<Planet*> m_aOwnedPlanets;
		vector<Planet*> m_aNotOwnedPlanets;
		vector<Planet*> m_aEnemyPlanets;
		vector<Planet*> m_aNeutralPlanets;

		vector<Fleet*> m_aOwnedFleets;
		vector<Fleet*> m_aEnemyFleets;
};

#endif
