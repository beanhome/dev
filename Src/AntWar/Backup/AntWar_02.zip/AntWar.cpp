#include "AntWar.h"
#include "Utils.h"

#include "NavDijkstra.h"
#include "NavAStar.h"

#ifdef MYDEBUG
#include "Graphic.h"

GraphicEngine ge(1024, 748, 32);
GraphicFrame gf_pw(&ge, 0, 0, 748, 748);
GraphicFrame gf_dbg(&ge, 748, 0, 276, 748);

#endif


//constructor
AntWar::AntWar()
	: m_oWorld()
{
}

//plays a single game of Ants.
void AntWar::PlayGame()
{
	m_oWorld.ReadSetup();

    EndTurn();

#ifdef MYDEBUG
	ge.Init();
#endif

	int iRound = 1;

	while(true)
	{
		uint16 iNewRound = iRound;

#ifdef MYDEBUG
		if (g_bVisualDebug)
		{
			while (iNewRound == iRound)
			{
				// Reset Data for new turn
				m_oWorld.NewTurn();

				// GetInfo
				if (m_oWorld.ReadTurn(iNewRound) == false)
				{
					iNewRound--;
					continue;
				}

				// Compute
				m_oWorld.UpdateVisionInformation();

				iNewRound = m_oWorld.DrawLoop(false);
				if (iNewRound == (uint16)-1)
					return;

				if (iNewRound == iRound)
				{
					// Execute
					MakeMoves();

					// End Turn
					EndTurn();

					iNewRound = m_oWorld.DrawLoop(true);
					if (iNewRound == (uint16)-1)
						return;
				}

				if (iNewRound == 0)
					iNewRound = 1;
			}
			iRound = iNewRound;
		}
		else
#endif
		{
			// Reset Data for new turn
			m_oWorld.NewTurn();

			// GetInfo
			if (m_oWorld.ReadTurn() == false)
				break;
			
			// Compute
			m_oWorld.UpdateVisionInformation();

			// Execute
			MakeMoves();

			// End Turn
			EndTurn();

			iRound++;
		}
	}


#ifdef MYDEBUG
	ge.Close();
#endif
};

//makes the bots moves for the turn
void AntWar::MakeMoves()
{
	NavDijkstra m_oNavDijkstra(m_oWorld.GetGrid());
	NavAStar m_oNavAStar(m_oWorld.GetGrid());

	vector<Vector2> aTargetLoc;
	aTargetLoc.reserve(m_oWorld.GetEnemyHills().size() + m_oWorld.GetFoods().size());
	for (uint i=0 ; i<m_oWorld.GetEnemyHills().size() ; ++i)
	{
		aTargetLoc.push_back(m_oWorld.GetEnemyHills()[i]);
	}
	for (uint i=0 ; i<m_oWorld.GetFoods().size() ; ++i)
	{
		aTargetLoc.push_back(m_oWorld.GetFoods()[i]);
	}

	vector<Vector2> aAntLoc;
	aAntLoc.reserve(m_oWorld.GetAnts().size());
	for (uint i=0 ; i<m_oWorld.GetAnts().size() ; ++i)
	{
		if (m_oWorld.GetAnts()[i].GetPlayer() == 0)
			aAntLoc.push_back(m_oWorld.GetAnts()[i].GetLocation());
	}

	if (aTargetLoc.size())
	{
		m_oNavDijkstra.Explore(aTargetLoc, aAntLoc, m_oWorld.GetTurn());

#ifdef MYDEBUG
		m_oNavDijkstra.PrintDebug();
#endif

		set<Path> m_AllPath;

		for (uint i=0 ; i<m_oWorld.GetAnts().size() ; ++i)
		{
			if (m_oWorld.GetAnts()[i].GetPlayer() == 0)
			{
				Path oPath;
				if (m_oNavDijkstra.GetPath(m_oWorld.GetAnts()[i].GetLocation(), oPath))
					m_AllPath.insert(oPath);
			}
		}

		Vector2 start(-1, -1);
		for (set<Path>::iterator it = m_AllPath.begin() ; it != m_AllPath.end() ; ++it)
		{
			const Path& oPath = *it;

			if (oPath.GetStart() != start)
			{
				Ant& oAnt = m_oWorld.GetAnt(oPath.GetTarget());
				if (oAnt.GetPath().size() == 0)
					oAnt.GetPath() = oPath.GetListInverse();
				start = oPath.GetStart();
			}
		}
	}

	for (uint i=0 ; i<m_oWorld.GetAnts().size() ; ++i)
	{
		Ant& oAnt = m_oWorld.GetAnts()[i];		
		if (oAnt.GetPlayer() != 0)
			continue;

		const Vector2& pos = oAnt.GetLocation();

		if (oAnt.GetPath().size() == 0)
		{
			oAnt.GetPath().clear();

			set<Path> aTargetMap;
			vector<Vector2> aPath;
			if (m_oNavDijkstra.FindNearest(pos, NavDijkstra::Undiscovered, aPath, m_oWorld.GetTurn()) != NavDijkstra::None)
			{
				aTargetMap.insert(Path(pos, aPath));
			}
			else if (m_oNavDijkstra.FindNearest(pos, NavDijkstra::Unvisible, aPath, m_oWorld.GetTurn()) != NavDijkstra::None)
			{
				aTargetMap.insert(Path(pos, aPath));
			}

			if (aTargetMap.size() > 0)
			{
				oAnt.GetPath() = aTargetMap.begin()->GetList();
			}
		}
		
		if (oAnt.GetPath().size() > 0)
		{
			EDirection dir;
			Vector2 target = oAnt.GetPath()[0];
			if (m_oWorld.IsEmpty(target))
			{
				dir = m_oWorld.GetDirection(pos, target);
				ExecMove(pos, dir);
			}
		}
	}
};

void AntWar::ExecMove(const Vector2 &loc, EDirection direction)
{
	cout << "o " << loc.y << " " << loc.x << " " << cDirChar[direction] << endl;

	m_oWorld.ExecMove(loc, direction);
}

void AntWar::EndTurn()
{
	//if(m_oWorld.turn > 0)
	//    m_oWorld.reset();
	//m_oWorld.turn++;

	cout << "go" << endl;
}
